#!/bin/bash
#author:vinod pawar

NAME="Vinod Pawar"
echo $NAME
unset NAME
echo $NAME