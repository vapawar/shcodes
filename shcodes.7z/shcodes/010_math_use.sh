#!/bin/sh
#author:vinod pawar

val='expr 2+2'
echo "Total is : $val"