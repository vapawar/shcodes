#!/bin/sh
#auhtor:vinod pawar

NAME[0]="VINOD"
NAME[1]="PAWAR"
NAME[2]="ARYAN"
NAME[3]="JATIN"
NAME[4]="ROHIT"

echo "First Method : ${NAME[*]}"
echo "Second Method : ${NAME[@]}"