#!/bin/sh
#author:vinod pawar

NAME[0]="VINOD"
NAME[1]="PAWAR"
NAME[2]="JAVA"
NAME[3]="PYTHON"
NAME[4]="SQL"

echo "First Index value is : ${NAME[0]}"
echo "Second Index value is : ${NAME[1]}"