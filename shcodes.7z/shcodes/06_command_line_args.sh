#!/bin/bash
#author:vinod pawar

echo "File Name : $0"
echo "First Parameter : $1"
echo "First Parameter : $2"
echo "quoted values : $@"
echo "quoted values : $*"
echo "total number parameters :$#"
echo "current process number is : $$"
echo "exit status of last cmd : $?"
echo "process number of last background cmd : $!"