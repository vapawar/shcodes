#!/bash/bash
#author:vinod pawar
#1st script on unix

pwd
ls