#!/bin/bash
#author:vinod pawar

echo "what is your name ?"
read PERSON
echo "Hello, $PERSON"