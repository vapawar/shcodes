#!/bin/bash
#auhor : vinod pawar

NAME="vinod pawar"
echo $NAME