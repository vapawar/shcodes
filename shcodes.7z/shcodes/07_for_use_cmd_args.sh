#!/bin/bash
#author:vinod pawar
for TOKEN in $*
do
echo $TOKEN
done

#provide following with script
#vinod pawar is computer engineer