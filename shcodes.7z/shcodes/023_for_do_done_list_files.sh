#!/bin/sh
for FILE in $HOME/.bash*
do
echo $FILE
done